export default async function handler(req, res) {
  const map = {
    "2025": "https://docs.google.com/spreadsheets/d/e/2PACX-1vSwe6NWvXzuU2JxVlTZ_NfClrjqhYreOzwlQbplaFeotgVSAVTdzqfRjaBQwkHOnirROx6Ouy524t3m/pub?gid=1589473865&single=true&output=csv",
    "2026": "https://docs.google.com/spreadsheets/d/e/2PACX-1vSwe6NWvXzuU2JxVlTZ_NfClrjqhYreOzwlQbplaFeotgVSAVTdzqfRjaBQwkHOnirROx6Ouy524t3m/pub?gid=1925020418&single=true&output=csv",
    "2027": "https://docs.google.com/spreadsheets/d/e/2PACX-1vSwe6NWvXzuU2JxVlTZ_NfClrjqhYreOzwlQbplaFeotgVSAVTdzqfRjaBQwkHOnirROx6Ouy524t3m/pub?gid=495375284&single=true&output=csv",
  };
  const ev = (req.query.ev || "2025").toString();
  const url = map[ev] || map["2025"];
  try {
    const resp = await fetch(url);
    const csv = await resp.text();
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.status(200).send(csv);
  } catch (e) {
    res.status(500).json({ error: "Nem sikerült lekérni a táblát." });
  }
}